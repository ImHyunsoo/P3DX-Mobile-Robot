/*
 * main.cpp
 *
 *  Created on: Dec 28, 2016
 *      Author: a
 */




#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

void timer_handler (int signum)
{
        static int count = 0;
        printf("timer expired %d timers\n", ++count);
}


int main ()
{
        struct sigaction sa;           // 시그널을 다루기 위해 사용
        struct itimerval timer;        // 타이머가 경과되는 때는 정하기 위해서 사용

        /* Install timer_handler as the signal handler for SIGVTALRM. */
        memset (&sa, 0, sizeof (sa));   // sa 구조체 0으로 초기화
        sa.sa_handler = &timer_handler;   //시그널 핸들러가 타이머 함수를 가르킴
        sigaction (SIGVTALRM, &sa, NULL);  //첫번째파라미터는 신호.
        //SIGVTALRM은 전형적으로 현재 프로세스에 의해 사용된 CPU시간을 계산하는 타이머의 경과를 지적
        //두번째 파라미터는 sigaction 구조체의 정보, 세번째는 이전 sigaction 구조체의 정보

        /* Configure the timer to expire after 250 msec... */
        timer.it_value.tv_sec = 0;             //첫번째 타이머 인터럽트 간격
        timer.it_value.tv_usec = 250000;

        /* ... and every 250 msec after that. */
        timer.it_interval.tv_sec = 0;         //연속적인 타이머 인터럽트들 사이의 간격
        timer.it_interval.tv_usec = 250000;

        /* Start a virtual timer. It counts down whenever this process is executing. */
        setitimer (ITIMER_VIRTUAL, &timer, NULL);     //타이머를 두번째 매개변수로 설정하고
        //타이머가 끝나면 첫번째 매개변수를 ITIMER_VIRTUAL로 하였으므로 SIGVTALRM신로를 보냄
        //ITIMER_VIRTUAL는 가상 타이머로 정함

        /* Do busy work.  */
        while (1);
}
