/*
 * main.cpp
 *
 *  Created on: Dec 30, 2016
 *      Author: a
 */




#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>

// 쓰레드 종료시 호출될 함수
void clean_up(void *);

// 쓰레드 함수
void *thread_func(void *);

pthread_cond_t cond = PTHREAD_COND_INITIALIZER;    // 조건 변수 초기화
pthread_mutex_t lmu = PTHREAD_MUTEX_INITIALIZER;

int main(int argc, char **argv)
{
    pthread_t pt;
    pthread_create(&pt, NULL, thread_func, NULL);

    // 생성된 쓰레드 pt에 취소 요청을 보낸다.
    pthread_cancel(pt);

    // 5초를 쉰 후에 시그널을 보낸다.
    sleep(3);
    pthread_cond_signal(&cond);

    // join후 종료한다.
    pthread_join(pt, NULL);
    printf("exit\n");
    exit(1);
}

// 쓰레드 종료시 효출될 함수
// 여기에 자원해제루틴을 입력할 수 있을 것이다.
void clean_up(void *arg)
{
    printf("Thread cancel Clean_up function\n");
}

void *thread_func(void *arg)
{
    // DISABLE 상태다.
    // 이경우 쓰레드에 대해서 취소 요청을 무시한다.
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);  //

    // 쓰레드 종료시 호출될 함수 등록
    pthread_cleanup_push(clean_up, (void *)NULL);
 //   pthread_cleanup_pop(0);

    pthread_mutex_lock(&lmu);
    printf("THREAD cond wait\n");
    pthread_cond_wait(&cond, &lmu);  //뮤텍스를 푼다음 조건변수에 시그널 들어올때까지 기다림,
    									//풀리면 다시 자동으로 뮤택스 잠금
    printf("NO WAIT COND\n");
    pthread_mutex_unlock(&lmu);

    printf("EXIT\n");
    pthread_cleanup_pop(0);
}
