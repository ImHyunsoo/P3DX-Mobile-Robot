#include <iostream>
#include <stdio.h>
//#include <sys/time.h>
#include <pthread.h>   //pthread 함수와 데이타 구조체
#include <unistd.h>    //sleep함수 포함

using namespace std;

int ncount = 0;

//뮤택스 생성 및 초기화
//fast mutex 뮤택스 잠근 뒤 또 잠그면 멈춤(데드락)
// 재귀적 뮤텍스는 잠근뒤 몇번이고 더 잠글수 있음
//걸었던 만큼 풀어줘야함 PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;


void* thread1(void* arg);    //쓰레드1 선언
void* thread2(void* arg);    //쓰레드2 선언

int main()
{
	pthread_t thread_id;             //쓰레드 리턴값을 위한 변수
	pthread_t p_thread1, p_thread2;  //쓰레드 구조체 객체 선언
	int status;

	int i = 1;

	printf("init main\n");

	//thread1 생성
	//첫번째 파라미터는 쓰레드에 대한 정보를 제공하기 위해
	//두번째는 새 쓰레드에 속성을 주기 위해 (NULL은 기본값 쓰게함)
	//세번째는 어떤함수에서 쓰레드가 시작할 것인지 알려줌
	//네번째는 함수로 넘겨줄 매개변수를 나타냄
	//리턴값은 성공이면 0반환
	if((thread_id = pthread_create(&p_thread1, NULL, thread1, NULL)))
		printf("Thread1[%d] Create Failed!\n", thread_id);
	else
		printf("Thread1[%d] Create Success!\n", thread_id);

	sleep(1);

	if((thread_id = pthread_create(&p_thread2, NULL, thread2, NULL)))
		printf("Thread2[%d] Create Failed!\n", thread_id);
	else
		printf("Thread2[%d] Create Success!\n", thread_id);

	sleep(1);

	while(1)
	{
		// 뮤택스를 걸음
		pthread_mutex_lock(&mutex);
		// 필요한 일함
		thread_id = pthread_self();
		printf("main = %d\n", i);
		//뮤택스를 풀음
		pthread_mutex_unlock(&mutex);
		i++;
		sleep(1);  //1초 지연

		if(i>2) break;
	}

	printf("thread1 cancel\n");


	//쓰레드를 끝내려고 할 때는 pthread_cancel쓰면 됨
	// 쓰레드 아이디를 파라미터로 받아 그 쓰레드 아이디로 취소 요청을 보냄
	// 이 요청에 대해 쓰레드가 어떻게 할지는 쓰레드의 상태에 달림
	// 즉시 취소되거나 취소위치에 다다랐을때 취소되거나 아예 무시할 수 있음
	// 0을 리턴
	//http://knight76.tistory.com/entry/20010117546 자세한 내용 참고
	if(pthread_cancel(p_thread1)) printf("pthread_cancel 1 failed\n");
	usleep(100);

	printf("thread2 cancel\n");

	if(pthread_cancel(p_thread2)) printf("pthread_cancel 2 failed\n");
	usleep(100);

	//뮤택스 없애기 0반환
	status = pthread_mutex_destroy(&mutex);
	printf("status %d\n", status);
	printf("End!!!\n");

	return 0;
}

//쓰레드 함수 정의
void* thread1(void* arg)
{
	int i, j;
	//취소요청을 받아 들일 것인지 아닌지를 결정
	//파라미터2개 필요함. 하나는 새로운 취소상태가 설정. 다른 하나는 이전 취소상태가 담길 변수
	// 두번째 파라미터가 NULL이면 이전 취소 상태에 대해 알 수 없음
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	//취소요청에 대한 반응을 결정. 이때 이 쓰레드는 취소될 수 있다고 가정
	//취소요청을 즉시(비동기적으로) 처리하는것과 취소위치에 도착하기전까지 취소를 미루는 것
	//취소를 미루려면 PTHREAD_CANCEL_DEFERRED
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

	printf("init thread1");
	i=1;
	j=2;
	printf("i=%d, j=%d\n", i, j);

	while(1)
	{
		pthread_mutex_lock(&mutex);
		printf("thread1 \n");
		pthread_mutex_unlock(&mutex);
		//취소위치는 보통, 쓰레드 실행을 오랫동안 정지시키는 함수
		// 취소위치에 쓰이는 함수가 실행중일 때, 뒤로 미룰 취소요청이 있는지 확인하고
		//취소요청이 들어와 있으면 자기가 끝난 다음에 취소작업을 실행한 뒤 종료함
		// 실행중 아니라면 pthread_testcancel()씀
		// 현재 쓰레드에서 대기중인 취소 요청이 있는지 확인해서 있다면 취소작업을 실행하고 없다면 리턴
		pthread_testcancel();
		usleep(100000);
	}
}

void* thread2(void* arg)
{
	int i, j;
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

	printf("init thread2");
	i=3;
	j=4;
	printf("i=%d, j=%d\n", i, j);

	while(1)
	{
		pthread_mutex_lock(&mutex);
		printf("thread2 \n");
		pthread_mutex_unlock(&mutex);
		pthread_testcancel();
		usleep(100000);
	}
}

















