/*
 * main.cpp
 *
 *  Created on: Jan 3, 2017
 *      Author: a
 */




#include <pthread.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>

/*
 * 시그널 핸들러
 * 핸들러가 호출된 쓰레드의 ID와 시그널 번호를 출력한다.
 */
void sig_handler(int signo)
{
    printf("SIGNAL RECV TH ID %d : %d\n", pthread_self(),signo);
}

void *threadfunc2(void *arg);
void *threadfunc(void *arg);
void *s_signal(void *arg);

// 쓰레드 ID를 저장한다.
pthread_t sigid[2];

int main()
{
    int n, i, j;
    pthread_t threadid;

    // 원하는 쓰레드로 시그널이 전달하는지 확인하기 위해서
    // 쓰레드 ID를 확인한다.
    if ((n = pthread_create(&threadid, NULL, threadfunc2, NULL)) != 0 )
    {
        perror("Thread create error ");
        exit(0);
    }
    sigid[0] = threadid;
    printf("thread2 id %d\n", threadid);

    if ((n = pthread_create(&threadid, NULL, threadfunc, NULL)) != 0 )
    {
        perror("Thread create error ");
        exit(0);
    }
    sigid[1] = threadid;
    printf("thread id %d\n", threadid);

    if ((n = pthread_create(&threadid, NULL, s_signal, NULL)) != 0 )
    {
        perror("Thread create error ");
        exit(0);
    }

    pthread_join(threadid, NULL);
}

void *threadfunc(void *arg)
{
    int i=0, j;
    struct sigaction act;
    sigset_t newmask;

    // 결과의 확인을 위해서 쓰레드 ID를 출력한다.
    printf("SIGINT Thread Start (%d)\n", pthread_self());

    // SIGINT에 대해서 시그널 핸들러를 등록했지만
    // SIGINT를 블럭하도록 했으므로 시그널은 전달되지 않는다.
    sigemptyset(&newmask);
    sigaddset(&newmask, SIGINT);
    act.sa_handler = sig_handler;
    sigaction(SIGINT, &act, NULL);
  //  pthread_sigmask(SIG_BLOCK, &newmask, NULL);

    while(1)
    {
        printf("%d\n", i);
        i++;
        sleep(1);
    }
    return NULL;
}

void *threadfunc2(void *arg)
{
    struct sigaction act;
	int lsigno;

    sigset_t newmask;
    sigemptyset(&newmask);
    sigaddset(&newmask, SIGINT);

	// 시그널 핸들러를 등록 시켰지만
	// sigwiat()가 가디리고 있으므로 실행되지 않는다.
    act.sa_handler = sig_handler;
    sigaction(SIGINT, &act, NULL);

    while(1)
    {
		sigwait(&newmask, &lsigno);
		printf("i receive signo %d\n", lsigno);
        sleep(1);
    }
}

/*
 * SIGINT를 두개의 쓰레드로 서로다른 시간간격으로
 * 전달한다.
 */
void *s_signal(void *arg)
{
    int i = 1;
    while(1)
    {
        sleep(1);
        i++;
        if((i % 7) == 0)
        {
            printf("Send SIGINT %d\n", sigid[0]);
            pthread_kill(sigid[0], SIGINT);
        }
        if((i % 11) == 0)
        {
            printf("Send SIGINT %d\n", sigid[1]);
            pthread_kill(sigid[1], SIGINT);
        }
    }
}
